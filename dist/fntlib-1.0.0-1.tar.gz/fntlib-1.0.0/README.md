# fntlib
**fntlib** is a Python library to interact with bitmap font (.fnt) files. It offers a simple modern Pythonic API and an intuitive workflow with an object oriented design.